//Copyright (c) 2017. 章钦豪. All rights reserved.
package com.monke.monkeybook.presenter.impl;

import com.monke.basemvplib.impl.IPresenter;

import java.util.LinkedHashMap;

public interface IFindBookPresenter extends IPresenter{
    void initData();
}
