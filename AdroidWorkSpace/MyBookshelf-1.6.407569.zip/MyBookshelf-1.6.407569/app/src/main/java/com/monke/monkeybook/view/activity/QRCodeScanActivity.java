package com.monke.monkeybook.view.activity;

import android.os.Bundle;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by GKF on 2018/1/29.
 */

public class QRCodeScanActivity extends CaptureActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
