//Copyright (c) 2017. 章钦豪. All rights reserved.
package com.monke.monkeybook.help;

public class RxBusTag {
    public final static String HAD_ADD_BOOK = "rxbus_add_book";
    public final static String HAD_REMOVE_BOOK = "rxbus_remove_book";
    public final static String UPDATE_BOOK_PROGRESS = "rxbus_update_book_progress";
    public final static String PAUSE_DOWNLOAD_LISTENER = "rxbus_pause_download_listener";
    public final static String PROGRESS_DOWNLOAD_LISTENER = "rxbus_progress_download_listener";
    public final static String FINISH_DOWNLOAD_LISTENER = "rxbus_finish_download_listener";
    public final static String PAUSE_DOWNLOAD = "rxbus_pause_download";
    public final static String START_DOWNLOAD = "rxbus_start_download";
    public final static String CANCEL_DOWNLOAD = "rxbus_cancel_download";
    public final static String ADD_DOWNLOAD_TASK = "rxbus_add_download_task";
    public final static String CHAPTER_CHANGE = "rxbus_chapter_change";
    public final static String MEDIA_BUTTON = "rxbus_media_button";
    public final static String ALOUD_MSG = "rxbus_aloud_string";
    public final static String ALOUD_STATE = "rxbus_aloud_state";
    public final static String ALOUD_INDEX = "rxbus_aloud_index";
    public final static String ALOUD_TIMER = "rxbus_aloud_timer";

}
