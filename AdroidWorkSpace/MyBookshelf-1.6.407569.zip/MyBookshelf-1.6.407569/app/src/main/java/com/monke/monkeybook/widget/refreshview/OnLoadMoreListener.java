package com.monke.monkeybook.widget.refreshview;

public interface OnLoadMoreListener {

    public void startLoadMore();

    public void loadMoreErrorTryAgain();
}
