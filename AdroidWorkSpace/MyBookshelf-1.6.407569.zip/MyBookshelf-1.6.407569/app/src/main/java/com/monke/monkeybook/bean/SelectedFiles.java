package com.monke.monkeybook.bean;

import java.io.File;
import java.util.HashMap;

public class SelectedFiles {
	public static HashMap<String, File> files = null;//文件路径-文件
	public static long totalFileSize = 0;//选中文件大小总和
}
