package com.monke.basemvplib.impl;

import android.content.Context;

public interface IView {
    Context getContext();
}
